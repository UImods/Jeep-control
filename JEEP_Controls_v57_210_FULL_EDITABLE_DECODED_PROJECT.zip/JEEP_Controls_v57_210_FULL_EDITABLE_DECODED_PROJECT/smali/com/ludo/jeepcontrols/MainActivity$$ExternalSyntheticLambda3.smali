.class public final synthetic Lcom/ludo/jeepcontrols/MainActivity$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/ludo/jeepcontrols/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/ludo/jeepcontrols/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ludo/jeepcontrols/MainActivity$$ExternalSyntheticLambda3;->f$0:Lcom/ludo/jeepcontrols/MainActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/ludo/jeepcontrols/MainActivity$$ExternalSyntheticLambda3;->f$0:Lcom/ludo/jeepcontrols/MainActivity;

    invoke-virtual {v0, p1}, Lcom/ludo/jeepcontrols/MainActivity;->lambda$onCreate$1$com-ludo-jeepcontrols-MainActivity(Landroid/view/View;)V

    return-void
.end method
